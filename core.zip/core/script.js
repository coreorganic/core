// Scratch and Win Game
document.querySelector(".scratch-box").addEventListener("click", function() {
    alert("You win a 10% discount!");
});
